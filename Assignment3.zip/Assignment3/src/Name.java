public enum Name {
    aragorn, legolas, gollum,frodo, sam, bilbo,sauron, saruman, faramir, denethor, treebeard, elrond,
    pippin, merry, gimli,gandalf, boromir, galadriel
}
