import java.util.ArrayList;

public class Ring implements Locations {
    private final ArrayList<Integer> locations = new ArrayList<>();

    public Ring() {
    }

    @Override
    public void addLocation(int location) {
        locations.add(location);
    }

    @Override
    public ArrayList<Integer> getLocations() {
        return locations;
    }
}
