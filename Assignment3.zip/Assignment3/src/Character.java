import java.util.ArrayList;

public class Character implements Locations {
    private final String name;
    private int appearanceCount;
    private int closenessCount;
    private double closenessFactor;
    private int occurrences;
    private ArrayList<Integer> locations= new ArrayList<>();

    public Character(String name) {
        this.name = name;
        this.appearanceCount = 0;
        this.closenessCount = 0;
    }

    public int getOccurrences(){ return appearanceCount; }

    public void incrementProximity(){ closenessCount++; }

    public int getProximity(){ return closenessCount; }

    public double getClosenessFactor(){ return closenessFactor = (double) closenessCount / appearanceCount; }



    public String getName() {
        return this.name;
    }

    public void incrementClosenessCount() {
        closenessCount++;
        closenessFactor = (double) closenessCount / appearanceCount;
    }


    @Override
    public void addLocation(int location) {
        locations.add(location);
        appearanceCount++;
    }

    @Override
    public ArrayList<Integer> getLocations() {
        return locations;
    }
}
