import java.util.ArrayList;

    interface Locations {
        void addLocation(int location);
        ArrayList<Integer> getLocations();
    }
